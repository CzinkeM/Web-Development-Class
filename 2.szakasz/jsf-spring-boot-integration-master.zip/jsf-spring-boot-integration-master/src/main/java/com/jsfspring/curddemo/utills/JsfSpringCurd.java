package com.jsfspring.curddemo.utills;

public final class JsfSpringCurd {

	private JsfSpringCurd() {
		throw new IllegalStateException("Constant Class");
	}

	public static final String employeeNotFound = "EmployeeNotFound";

}